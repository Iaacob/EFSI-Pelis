import Header from "./components/Header";
import Footer from "./components/Footer";
import Mensaje from "./components/Mensaje";
import ListadoPersonas from "./components/ListadoPersonas";
import Soplon from "./components/Soplon";

function App() {

  const arrayPersonas = [
    {
      nombre:"martin",
      apellido:"esses",
      descripcion:"Some quick example text to build on the card title and make up the bulk of the card's content."
    },
    {
      nombre:"damian",
      apellido:"jose",
      descripcion:"Some ."
    },
    {
      nombre:"carlos",
      apellido:"gonzalez",
      descripcion:"Some quick example text to build on "
    },
    {
      nombre:"carlos2",
      apellido:"gonzalez2",
      descripcion:"Some quick example text to build on "
    }
  ];

  const Mostrar = (nombre)=>{
    console.log('Mostrar Persona en modal ' + nombre);
  }

  return (
    <>
      <Header />

      <Soplon />

      <div className="container">
        <div className="row">
          <ListadoPersonas mostrarModal={Mostrar} items={arrayPersonas} />    
        </div>
      </div> 
      

      <Mensaje titulo="Mensaje primario" tipo="alert-primary" />
      <Mensaje titulo="Mensaje secundario" tipo="alert-secondary"/>      
      <Mensaje titulo="Mensaje de warning" tipo="alert-warning"/>      
      <Mensaje titulo="Mensaje de error" tipo="alert-danger"/>      
      <Footer />
    </>
  );
}

export default App;
