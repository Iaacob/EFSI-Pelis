import React from 'react';

const Footer = () => {
    return ( 
        <div className="container">
            <div className="row">
                <div className="col-md-12">
                    Todos los derechos reservados .....
                </div>
            </div>
        </div>
     );
}
 
export default Footer;