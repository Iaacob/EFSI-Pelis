import React from 'react';
import Navbar from './Navbar';

const Header = () => {
    return ( 
        <div className="container">
            <div className="row">
                <div className="col-md-4">
                    Logo
                </div>
                <div className="col-md-8 align-end">
                    <Navbar />                    
                </div>
            </div>            
        </div>
    );
}
 
export default Header;