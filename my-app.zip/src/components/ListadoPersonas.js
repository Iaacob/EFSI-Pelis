import React from 'react';
import Persona from './Persona';

const ListadoPersonas = ({items, mostrarModal}) => {    
    return ( 
        <>
        {items.map(persona=>(
            <div key={persona.nombre} className="col-md-4">
            <Persona persona={persona} mostrarModal={mostrarModal}/>
          </div>
          ))} 
        </>
     );
}
 
export default ListadoPersonas;