import React from 'react';

const Mensaje = ({titulo,tipo}) => {
    return ( 
        <div className={`alert ${tipo}`} role="alert">
            {titulo}
        </div>
    );
}
 
export default Mensaje;