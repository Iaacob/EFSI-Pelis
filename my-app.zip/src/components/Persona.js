import React from 'react';

const Persona = ({persona,mostrarModal}) => {
    const {nombre,apellido,descripcion} = persona;

    return ( 
        <div className="card">            
            <div className="card-body">
                <h5 className="card-title">{nombre} {apellido}</h5>
                <p className="card-text">{descripcion}</p>
                <button 
                    onClick={()=>mostrarModal(nombre)} 
                    className="btn btn-primary">
                    Go somewhere
                </button>
            </div>
        </div>
    );
}
 
export default Persona;