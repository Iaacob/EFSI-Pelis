import React from "react";

const Soplon = () => {
  const handleChange = (e) => {
    console.log(e.target.value);
  };

 return (
    <input type="text" name="buscador" onChange={handleChange} />
  )
};

export default Soplon;
